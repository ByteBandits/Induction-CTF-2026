from flask import Flask, request, render_template, render_template_string, send_from_directory, abort
import os

app = Flask(__name__, template_folder='templates')

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/hello', methods=['GET', 'POST'])
def render_view():
    name = request.values.get('name', 'Guest')
    template = "Hello " + name + "!"
    return render_template_string(template)

if __name__ == "__main__":
    app.run(
        host="0.0.0.0",
        port=int(os.environ.get("PORT", 5000)),
        debug=False
    )
