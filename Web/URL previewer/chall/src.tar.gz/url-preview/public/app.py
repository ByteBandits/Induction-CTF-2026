import socket
import ipaddress
import requests
from urllib.parse import urlparse
from flask import Flask, request, render_template

app = Flask(__name__)

MAX_BYTES = 50_000
TIMEOUT = (2, 3)
MAX_REDIRECTS = 5

def safe_fetch(url):
    session = requests.Session()

    session.max_redirects = MAX_REDIRECTS

    headers = {
        "User-Agent": "CTF-URL-Previewer/1.0"
    }

    with session.get(
        url,
        headers=headers,
        timeout=TIMEOUT,
        stream=True,
        allow_redirects=True
    ) as r:

        r.raise_for_status()

        content = b""
        for chunk in r.iter_content(chunk_size=1024):
            if not chunk:
                break
            content += chunk
            if len(content) > MAX_BYTES:
                break

        return content.decode(errors="replace")

def is_ip_literal(host):
    try:
        ipaddress.ip_address(host)
        return True
    except ValueError:
        return False

def is_blocked(hostname):
    if is_ip_literal(hostname):
        ip = ipaddress.ip_address(hostname)
        if ip.is_loopback or ip.is_private or ip.is_link_local:
            return True
        return False

    try:
        addrinfo = socket.getaddrinfo(hostname, None, proto=socket.IPPROTO_TCP)
        resolved_ips = [info[4][0] for info in addrinfo]
    except Exception:
        return True

    if not resolved_ips:
        return True

    first_ip = resolved_ips[0]

    if "127.0.0.1" in resolved_ips or "::1" in resolved_ips:
        return True

    return False

@app.route("/", methods=["GET", "POST"])
def index():
    result = ""
    if request.method == "POST":
        url = request.form.get("url", "")
        try:
            parsed = urlparse(url)
            hostname = parsed.hostname

            if not hostname:
                raise Exception("Invalid URL")

            if is_blocked(hostname):
                result = "Blocked host"
            else:
                result = safe_fetch(url)

        except requests.exceptions.Timeout:
            result = "Request timed out"
        except requests.exceptions.TooManyRedirects:
            result = "Too many redirects"
        except requests.exceptions.RequestException as e:
            result = f"Request error: {e}"
        except Exception as e:
            result = f"Error: {e}"

    return render_template("index.html", result=result)

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=False)
